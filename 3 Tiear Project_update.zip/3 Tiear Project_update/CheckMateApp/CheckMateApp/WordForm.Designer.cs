﻿namespace CheckMateApp
{
    partial class WordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1_Word = new System.Windows.Forms.MenuStrip();
            this.goTOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.letterQuizToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sentenceQuizToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selfQuizToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkResultToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1_Word.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1_Word
            // 
            this.menuStrip1_Word.BackColor = System.Drawing.Color.RoyalBlue;
            this.menuStrip1_Word.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.goTOToolStripMenuItem,
            this.settingToolStripMenuItem,
            this.logOutToolStripMenuItem});
            this.menuStrip1_Word.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1_Word.Name = "menuStrip1_Word";
            this.menuStrip1_Word.Size = new System.Drawing.Size(834, 27);
            this.menuStrip1_Word.TabIndex = 2;
            this.menuStrip1_Word.Text = "menuStrip1";
            // 
            // goTOToolStripMenuItem
            // 
            this.goTOToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.letterQuizToolStripMenuItem,
            this.sentenceQuizToolStripMenuItem,
            this.selfQuizToolStripMenuItem,
            this.checkResultToolStripMenuItem,
            this.checkReportsToolStripMenuItem});
            this.goTOToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goTOToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.goTOToolStripMenuItem.Image = global::CheckMateApp.Properties.Resources.searchItem;
            this.goTOToolStripMenuItem.Name = "goTOToolStripMenuItem";
            this.goTOToolStripMenuItem.Size = new System.Drawing.Size(74, 23);
            this.goTOToolStripMenuItem.Text = "Go to";
            // 
            // letterQuizToolStripMenuItem
            // 
            this.letterQuizToolStripMenuItem.Name = "letterQuizToolStripMenuItem";
            this.letterQuizToolStripMenuItem.Size = new System.Drawing.Size(173, 24);
            this.letterQuizToolStripMenuItem.Text = "Letter quiz";
            this.letterQuizToolStripMenuItem.Click += new System.EventHandler(this.letterQuizToolStripMenuItem_Click);
            // 
            // sentenceQuizToolStripMenuItem
            // 
            this.sentenceQuizToolStripMenuItem.Name = "sentenceQuizToolStripMenuItem";
            this.sentenceQuizToolStripMenuItem.Size = new System.Drawing.Size(173, 24);
            this.sentenceQuizToolStripMenuItem.Text = "Sentence quiz";
            this.sentenceQuizToolStripMenuItem.Click += new System.EventHandler(this.sentenceQuizToolStripMenuItem_Click);
            // 
            // selfQuizToolStripMenuItem
            // 
            this.selfQuizToolStripMenuItem.Name = "selfQuizToolStripMenuItem";
            this.selfQuizToolStripMenuItem.Size = new System.Drawing.Size(173, 24);
            this.selfQuizToolStripMenuItem.Text = "Self quiz";
            this.selfQuizToolStripMenuItem.Click += new System.EventHandler(this.selfQuizToolStripMenuItem_Click);
            // 
            // checkResultToolStripMenuItem
            // 
            this.checkResultToolStripMenuItem.Name = "checkResultToolStripMenuItem";
            this.checkResultToolStripMenuItem.Size = new System.Drawing.Size(173, 24);
            this.checkResultToolStripMenuItem.Text = "Check result";
            this.checkResultToolStripMenuItem.Click += new System.EventHandler(this.checkResultToolStripMenuItem_Click);
            // 
            // checkReportsToolStripMenuItem
            // 
            this.checkReportsToolStripMenuItem.Name = "checkReportsToolStripMenuItem";
            this.checkReportsToolStripMenuItem.Size = new System.Drawing.Size(173, 24);
            this.checkReportsToolStripMenuItem.Text = "Check reports";
            this.checkReportsToolStripMenuItem.Click += new System.EventHandler(this.checkReportsToolStripMenuItem_Click);
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.settingToolStripMenuItem.Image = global::CheckMateApp.Properties.Resources.Home_icon;
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(77, 23);
            this.settingToolStripMenuItem.Text = "Home";
            this.settingToolStripMenuItem.Click += new System.EventHandler(this.settingToolStripMenuItem_Click);
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.logOutToolStripMenuItem.Image = global::CheckMateApp.Properties.Resources.LogOut;
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(88, 23);
            this.logOutToolStripMenuItem.Text = "Log out";
            // 
            // WordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CheckMateApp.Properties.Resources.main_back;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(834, 461);
            this.Controls.Add(this.menuStrip1_Word);
            this.MaximizeBox = false;
            this.Name = "WordForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Word Testing";
            this.menuStrip1_Word.ResumeLayout(false);
            this.menuStrip1_Word.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1_Word;
        private System.Windows.Forms.ToolStripMenuItem goTOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem letterQuizToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sentenceQuizToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selfQuizToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkResultToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
    }
}