﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Leap;
using BusinessAccessLayer;
using UserObjectLayer;

namespace CheckMateApp
{
    public partial class LetterForm : Form
    {

        public Informations info = new Informations();
        public CoordinateManager con = new CoordinateManager();

        private int quectionCount = 5;
        private int[] quectionList ;
        private int[] quectionResult;
        private Boolean[] quectionResultMap;
        private int userID = 3;
        private QuectionPaper quectionPaper;        

        public LetterForm()
        {
            InitializeComponent();
            quectionPaper = new QuectionPaper(info, con);
            quectionList = quectionPaper.getNextPaper(userID);
            quectionResultMap = new Boolean[quectionList.Length];
            using (Controller controller = new Controller())
            {
                controller.FrameReady += newFrameHandler;
            }

            // temporary work
            quectionResult = new int[5] { 1, 1, 0, 1, 0};
        }

        private void newFrameHandler(object sender, FrameEventArgs e)
        {
            Boolean Thumb = false;
            Boolean Index = false;
            Boolean Middle = false;
            Boolean Ring = false;
            Boolean Pinky = false;
            Frame frameval = e.frame;
            foreach (Hand hand in frameval.Hands)
            {
                Finger Finger_Details001 = hand.Fingers[0];
                Finger Finger_Details002 = hand.Fingers[1];
                Finger Finger_Details003 = hand.Fingers[2];
                Finger Finger_Details004 = hand.Fingers[3];
                Finger Finger_Details005 = hand.Fingers[4];
                double Finger1 = Convert.ToDouble(Math.Round(Finger_Details001.Direction.Yaw, 2));
                double Finger2 = Convert.ToDouble(Math.Round(Finger_Details002.Direction.Yaw, 2));
                double Finger3 = Convert.ToDouble(Math.Round(Finger_Details003.Direction.Yaw, 2));
                double Finger4 = Convert.ToDouble(Math.Round(Finger_Details004.Direction.Yaw, 2));
                double Finger5 = Convert.ToDouble(Math.Round(Finger_Details005.Direction.Yaw, 2));
                for (int i = 0; i < hand.Fingers.Count; i++)
                {
                    Finger fingerData = hand.Fingers[i];
                    if (fingerData.IsExtended)
                    {
                        if (fingerData.Type == Finger.FingerType.TYPE_THUMB)
                        {
                            Thumb = true;
                        }
                        else if (fingerData.Type == Finger.FingerType.TYPE_INDEX)
                        {
                            Index = true;
                        }
                        else if (fingerData.Type == Finger.FingerType.TYPE_MIDDLE)
                        {
                            Middle = true;
                        }
                        else if (fingerData.Type == Finger.FingerType.TYPE_RING)
                        {
                            Ring = true;
                        }
                        else if (fingerData.Type == Finger.FingerType.TYPE_PINKY)
                        {
                            Pinky = true;
                        }
                    }
                }
                checkletter(Thumb, Index, Middle, Ring, Pinky,Finger1,Finger2,Finger3,Finger4,Finger5);
            }
        }
        private void checkletter(bool Thumb, bool Index, bool Middle, bool Ring, bool Pinky,double analysis001,double analysis002,double analysis003,double analysis004,double analysis005)
        {
            info.Thumb = Thumb;
            info.Index = Index;
            info.Middle = Middle;
            info.Ring = Ring;
            info.Pinky = Pinky;
            info.Thumb_Coordinate001 = analysis001;
            info.Index_Coordinate002 = analysis002;
            info.Middle_Coordinate003 = analysis003;
            info.Ring_Coordinate004 = analysis004;
            info.Pinky_Coordinate005 = analysis005;
            
            string letter = con.getMatchLetterFromDB(info);
            if (label1.Text == letter)
            {
                btnq_1.BackColor = Color.Green;
                label2.Text = "letter has been match"+letter+"";
            }

            //staus (true or false) for questions after matching a letter should set in quectionResultMap 
            quectionResultMap[1] = false;
            quectionResultMap[2] = true;
            quectionResultMap[3] = true;
            quectionResultMap[4] = false;
            quectionResultMap[5] = true;    
     
        }
        private void settingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormMainPage mainpage = new FormMainPage();
            this.Hide();
            mainpage.Show();
        }
        private void wordQuizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WordForm word = new WordForm();
            this.Hide();
            word.Show();
        }

        private void sentenceQuizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SentenceForm sentence = new SentenceForm();
            this.Hide();
            sentence.Show();
        }

        private void selfQuizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SelfForm self = new SelfForm();
            this.Hide();
            self.Show();
        }

        private void checkResultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResultForm result = new ResultForm();
            this.Hide();
            result.Show();
        }

        private void checkReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportsForm report = new ReportsForm();
            this.Hide();
            report.Show();
        }

        public void Recall_Letter(int letterID)
        {
            DataSet letterList = new DataSet();
            if (letterID < quectionCount)
            {
                info.letterID = quectionList[letterID];
                
                letterList = con.FindLeter(info);
                if (letterList.Tables[0].Rows.Count > 0)
                {
                    label1.Text = letterList.Tables[0].Rows[0][0].ToString();
                }
            }            
        }
        private void btnStart_Click(object sender, EventArgs e)
        {
           
        }
        private void btnq_1_Click(object sender, EventArgs e)
        {
            Recall_Letter(0);
        }

        private void btnq_2_Click(object sender, EventArgs e)
        {
            Recall_Letter(1);
        }

        private void btnq_3_Click(object sender, EventArgs e)
        {
            Recall_Letter(2);
        }

        private void btnq_4_Click(object sender, EventArgs e)
        {
            Recall_Letter(3);
        }

        private void btnq_5_Click(object sender, EventArgs e)
        {
            Recall_Letter(4);
        }

        private void btnq_6_Click(object sender, EventArgs e)
        {
            Recall_Letter(5);
        }

        private void btnq_7_Click(object sender, EventArgs e)
        {
            Recall_Letter(6);
        }

        private void btnq_8_Click(object sender, EventArgs e)
        {
            Recall_Letter(7);
        }

        private void btnq_9_Click(object sender, EventArgs e)
        {
            Recall_Letter(8);
        }

        private void btnq_10_Click(object sender, EventArgs e)
        {
            Recall_Letter(9);
        }

        private void label2_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int marks = quectionPaper.submit(userID, quectionResult, quectionList);   
            CustomMessageBox.Show(marks);
        }
        }
    }




