﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CheckMateApp
{
    public partial class CustomMessageBox : Form
    {
        public CustomMessageBox()
        {
            InitializeComponent();
        }
        static CustomMessageBox MsgBox ; static DialogResult result = DialogResult.No;
        public static DialogResult Show(int marks)
        {
            MsgBox = new CustomMessageBox();
            String message;      

            if (marks == 5)
            {
                message = "Excellent";
                MsgBox.pictureBox1.Image = Properties.Resources._5;
                MsgBox.lbl_result.Text = marks.ToString();
            }
            else if (marks == 4)
            {
                message = "Good";
                MsgBox.pictureBox1.Image = Properties.Resources._4;
                MsgBox.lbl_result.Text = marks.ToString();
            }
            else if (marks == 3)
            {
                message = "Some what OK";
                MsgBox.pictureBox1.Image = Properties.Resources._3;
                MsgBox.lbl_result.Text = marks.ToString();
            }
            else if (marks == 2)
            {
                message = "Improve";
                MsgBox.pictureBox1.Image = Properties.Resources._2;
                MsgBox.lbl_result.Text = marks.ToString();
            }
            else if (marks == 1)
            {
                message = "Bad";
                MsgBox.pictureBox1.Image = Properties.Resources._1;
                MsgBox.lbl_result.Text = marks.ToString();
            }
            else if (marks == 0)
            {
                message = "Too Bad";
                MsgBox.pictureBox1.Image = Properties.Resources._0;
                MsgBox.lbl_result.Text = marks.ToString();
            }
            else if (marks == -1)
            {
                message = "Already submitted";
                MsgBox.pictureBox1.Image = Properties.Resources._default;
                MsgBox.lbl_result.Text = null;
            }
            else
            {
                message = "Some thing has wrong!";
                MsgBox.pictureBox1.Image = Properties.Resources.error;
            }
            MsgBox.lbl_message.Text = message;                        
            MsgBox.ShowDialog();
            return result;
        }
        private void CustomMessageBox_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            result = DialogResult.Yes; MsgBox.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

    }
}
