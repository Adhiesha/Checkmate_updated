﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using UserObjectLayer;
using System.Data;
using System.Data.SqlClient;
namespace BusinessAccessLayer
{
   public class CoordinateManager
    {
       public Dbconnection db = new Dbconnection();
       public Informations info = new Informations(); 

       public System.Data.DataSet FindLeter(Informations info)
       {
           SqlCommand cmd = new SqlCommand();
           cmd.CommandType = CommandType.Text;
           cmd.CommandText = "select q.LETTER from t001_Quiz q where q.ID='" + info.letterID + "'";
           return db.Exedataset(cmd, "t001_Quiz");
       }

       public string getMatchLetterFromDB(Informations info)
       {
           SqlCommand cmd = new SqlCommand("dbo.GetMatchLetter");
           cmd.Parameters.Add("IsThumb", SqlDbType.Bit).Value = info.Thumb;
           cmd.Parameters.Add("IsIndex", SqlDbType.Bit).Value = info.Index;
           cmd.Parameters.Add("IsMiddle", SqlDbType.Bit).Value = info.Middle;
           cmd.Parameters.Add("IsRing", SqlDbType.Bit).Value = info.Ring;
           cmd.Parameters.Add("IsPinky", SqlDbType.Bit).Value = info.Pinky;
           cmd.Parameters.Add("Thumb_coordinate001", SqlDbType.Float).Value = info.Thumb_Coordinate001;
           cmd.Parameters.Add("Index_coordinate002", SqlDbType.Float).Value = info.Index_Coordinate002;
           cmd.Parameters.Add("Middle_coordinate003 ", SqlDbType.Float).Value = info.Middle_Coordinate003;
           cmd.Parameters.Add("Ring_coordinate004", SqlDbType.Float).Value = info.Ring_Coordinate004;
           cmd.Parameters.Add("Pinky_coordinate005", SqlDbType.Float).Value = info.Pinky_Coordinate005;
           cmd.CommandType = CommandType.StoredProcedure;
           return db.ExeLetterFinder(cmd);          
       }

       public DataSet getAllLetters()
       {
           SqlCommand cmd = new SqlCommand();
           cmd.CommandType = CommandType.Text;
           cmd.CommandText = "select ID from t001_Quiz";
           return db.Exedataset(cmd, "t001_Quiz");
       }

       public DataSet getNextPaper(Informations info)
       {
           SqlCommand cmd = new SqlCommand();
           cmd.CommandType = CommandType.StoredProcedure;
           cmd.CommandText = "usp_getNextPaper";                    

           SqlParameter paramUserID = new SqlParameter("@UserID", info.userID);
           paramUserID.Direction = ParameterDirection.Input;
           paramUserID.DbType = DbType.String;
           cmd.Parameters.Add(paramUserID);

           return db.ExecuteStoredPosedure(cmd);
       }

        public DataSet getQuestionDifficulty(Informations info)
        { 
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select difficult_level from QuesDifficult qd where qd.ID=" + info.letterID + "";
            return db.Exedataset(cmd, "QuesDifficult");
        }

        public DataSet getUserAttemptCount(Informations info)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select attemptCount from UserAttempts ua where ua.UserID =" + info.userID + "";
            return db.Exedataset(cmd, "UserAttempts");
        }
        public int setUserMarks(Informations info)
        {
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into UserMarks (UserID,marks,attempt,letterID,letterResult) values "+info.resultString+"";
                return db.ExecuteQuery(cmd);
            }
        }

        public int updateUserAttemptCount(Informations info)
        {
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update UserAttempts  set  attemptCount =" + info.attempt + " where UserID = " + info.userID + "";
                return db.ExecuteQuery(cmd);
            }
        }
        public int insertUserAttemptCount(Informations info)
        {
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into UserAttempts (UserID,attemptCount) values ("+ info.userID +"," + info.attempt + ")";
                return db.ExecuteQuery(cmd);
            }
        }

        public int updateDifficultyLevel(Informations info)
        {
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update QuesDifficult  set  difficult_level =" + info.difficulty + " where ID = " + info.letterID + "";
                return db.ExecuteQuery(cmd);
            }
        }

        public DataSet getUserMarks(Informations info)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select attemptCount from UserAttempts ua where ua.UserID =" + info.userID + "";
            return db.Exedataset(cmd, "UserAttempts");
        }
       

    }
}
    